# Hosting on GitHub Pages

## Folder layout
```
index (none)          <- the root has no page; participants get direct links
search/index.html     <- search engine condition  (address: /search/)
search/*.html         <- the four article pages the results link to
chat/index.html       <- chatbot condition        (address: /chat/)
robots.txt, .nojekyll <- keep search engines out / make GitHub serve files as-is
```

## Steps
1. Create a new GitHub repository (it must be **public** on the free plan for Pages).
2. Upload the *contents* of this folder (not the folder itself) to the repository root.
   Easiest: on the repo page choose Add file > Upload files, drag everything in
   (including the `search` and `chat` folders and the hidden `.nojekyll` file), then Commit.
3. Settings > Pages > Source: "Deploy from a branch", Branch: `main`, folder `/ (root)`. Save.
4. After a minute your links are:
   - https://YOUR-USERNAME.github.io/REPO-NAME/search/
   - https://YOUR-USERNAME.github.io/REPO-NAME/chat/
5. Put those links in Qualtrics. Test both in a private window.

## Tips
- Use a neutral repo name (not "study", "mock", "experiment"), since it shows in the address.
- For a cleaner address, add a custom domain in Settings > Pages.
- Pages carry a "noindex" tag and robots.txt, so search engines should not list them.
  Anyone with the link can still open them.

## Completion codes
- Search page: SE-<results clicked in order, dot separated>-T<seconds>-<checksum>
  1 = What is magnesium? | 2 = Benefits and dosage | 3 = Symptoms | 4 = Food sources
- Chatbot: CB-<sections viewed in order>[.E if ended early]-T<seconds>-<checksum>
  Same numbering; E = participant chose "I don't want to know more."
- Checksum: FNV-1a hash of the text before it, base-36, last 4 characters uppercased.
